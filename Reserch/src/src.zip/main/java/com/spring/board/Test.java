package com.spring.board;

public class Test {
	
	public static void main(String[] args) {
		
		String a = "";
		
		String[] b=a.split(",");
		
		
		System.out.println(b[0]);
		System.out.println(b.length);
			
		// 길이는 1을 같고 시작한다.
		
		
		
		
	}
	
}
