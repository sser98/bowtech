package com.spring.board.common;

public class SecretMyKey {

	public final static String KEY = "abcd0070#cclass$";
	
}
